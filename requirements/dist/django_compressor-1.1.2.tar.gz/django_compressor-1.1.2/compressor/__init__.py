# following PEP 386, versiontools will pick it up
__version__ = (1, 1, 2, "final", 0)
