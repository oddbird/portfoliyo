======================
django-inmemorystorage
======================

A non-persistent in-memory data storage backend for Django.

Compatible with Django's `storage API <https://docs.djangoproject.com/en/dev/ref/files/storage/>`_.
