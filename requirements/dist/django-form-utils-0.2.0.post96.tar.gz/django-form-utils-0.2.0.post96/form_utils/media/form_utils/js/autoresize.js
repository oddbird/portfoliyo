$(document).ready(function() {
	$('textarea.autoresize').autogrow();
    });
