CHANGES
=======

0.1.7 (2012.11.06)
------------------

* JS stop transient-message fade on close-link click.

0.1.6 (2012.10.05)
------------------

* JS don't parse non-json.

0.1.5 (2012.07.23)
------------------

* Don't touch non-200 responses.

0.1.4 (2011.07.14)
------------------

* JS cleanup; added JSLint options.

0.1.3 (2011.06.28)
------------------

* Added ``closeLink: false`` plugin option.
* Subsequent plugin calls on the same element default to previous options
  unless explicitly overridden.

0.1.2 (2011.06.27)
------------------

* Added ``AjaxMessagesMiddleware`` and ``handleAjax`` plugin option.


0.1.1 (2011.06.27)
------------------

* Updated HTML template (removed ``<aside>`` and moved ``#messages`` to
  ``<ul>``).


0.1.0 (2011.06.25)
------------------

* Initial release.
