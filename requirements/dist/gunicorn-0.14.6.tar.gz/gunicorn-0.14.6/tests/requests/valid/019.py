request = {
    "method": "GET",
    "uri": uri("/first"),
    "version": (1, 0),
    "headers": [],
    "body": ""
}