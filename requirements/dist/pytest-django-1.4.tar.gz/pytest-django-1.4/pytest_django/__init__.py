from pytest_django.plugin import *
from pytest_django.funcargs import *
from pytest_django.marks import *

# When Python 2.5 support is dropped, these imports can be used instead:
# from .plugin import *
# from .funcargs import *
# from .marks import *
