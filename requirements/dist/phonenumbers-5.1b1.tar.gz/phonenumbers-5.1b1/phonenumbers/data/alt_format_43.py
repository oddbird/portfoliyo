"""Auto-generated file, do not edit by hand. 43 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_43 = [NumberFormat(pattern='(5)(\\d{3,12})', format=u'\\1 \\2', leading_digits_pattern=['5[079]']), NumberFormat(pattern='(50)(\\d{2})(\\d{2})(\\d{2,4})', format=u'\\1 \\2 \\3 \\4', leading_digits_pattern=['50']), NumberFormat(pattern='(5\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2,4})', format=u'\\1 \\2 \\3 \\4 \\5', leading_digits_pattern=['5[079]']), NumberFormat(pattern='(5\\d)(\\d{5})(\\d{4,6})', format=u'\\1 \\2 \\3', leading_digits_pattern=['5[079]']), NumberFormat(pattern='(5\\d)(\\d{6,7})', format=u'\\1 \\2', leading_digits_pattern=['5[079]'])]
