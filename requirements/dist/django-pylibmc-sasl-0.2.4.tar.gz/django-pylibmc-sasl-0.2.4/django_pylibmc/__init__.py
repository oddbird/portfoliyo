VERSION = (0, 2, 4)
__version__ = '.'.join(map(str, VERSION))
