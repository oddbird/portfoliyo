CHANGES
=======

0.1.1 (2011.07.14)
------------------

* JS cleanup; added JSLint options.

0.1.0 (2011.06.26)
------------------

* Initial release.

