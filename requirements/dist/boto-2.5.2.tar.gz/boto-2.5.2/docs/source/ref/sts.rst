.. ref-sts

===
STS
===

boto.sts
--------

.. automodule:: boto.sts
   :members:   
   :undoc-members:

.. autoclass:: boto.sts.STSConnection
   :members:
   :undoc-members:

boto.sts.credentials
--------------------

.. automodule:: boto.sts.credentials
   :members:   
   :undoc-members:
   

