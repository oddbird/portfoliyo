#!/usr/bin/env python

import tests

tests.run()
